#include "sensors.h"
#include "config.h"
#include <Arduino.h>

// ═══════════════════════════════════════════════════════════════
//  YL-69
// ═══════════════════════════════════════════════════════════════

static bool yl69Inicializado = false;

void yl69_init() {
    // GPIO35 es input-only en ESP32; analogRead() funciona sin pinMode explícito.
    // El módulo YL-69 debe contar con resistencia pull-down externa (ver notas de hardware).
    analogSetPinAttenuation(PIN_SENSOR_HUMEDAD, ADC_11db);  // Rango 0–3.3 V en ESP32
    yl69Inicializado = true;
}

float yl69_leer() {
    if (!yl69Inicializado) return 0.0f;

    // Promedio de 5 lecturas para reducir ruido ADC
    long suma = 0;
    for (int i = 0; i < 5; i++) {
        suma += analogRead(PIN_SENSOR_HUMEDAD);
    }
    float valorADC = suma / 5.0f;

    // El YL-69 tiene respuesta inversa: ADC alto = suelo seco, ADC bajo = suelo húmedo
    float humedad = ((float)(YL69_SECO_ADC - valorADC) /
                     (float)(YL69_SECO_ADC - YL69_MOJADO_ADC)) * 100.0f;

    if (humedad < 0.0f)   humedad = 0.0f;
    if (humedad > 100.0f) humedad = 100.0f;
    return humedad;
}

bool yl69_listo() {
    return yl69Inicializado;
}

// ═══════════════════════════════════════════════════════════════
//  J35C1
// ═══════════════════════════════════════════════════════════════

static int            _conteoGotas    = 0;
static unsigned long  _tiempoInicio   = 0;
static bool           _midiendo       = false;
static bool           _estadoAnterior = false;  // true = gota presente en último tick

void j35c1_init() {
    analogSetPinAttenuation(PIN_SENSOR_LLUVIA, ADC_11db);
    _midiendo       = false;
    _conteoGotas    = 0;
    _estadoAnterior = false;
}

void j35c1_iniciarMedicion() {
    _conteoGotas    = 0;
    _tiempoInicio   = millis();
    _midiendo       = true;
    _estadoAnterior = false;
}

// Detección por flanco descendente (HIGH → LOW) del ADC.
// Cada transición representa el inicio de una gota nueva.
void j35c1_actualizar() {
    if (!_midiendo) return;

    int  valorADC   = analogRead(PIN_SENSOR_LLUVIA);
    bool gotaActual = (valorADC < UMBRAL_GOTA_ADC);

    if (gotaActual && !_estadoAnterior) {
        _conteoGotas++;
    }
    _estadoAnterior = gotaActual;
}

int j35c1_conteoGotas() {
    return _conteoGotas;
}

unsigned long j35c1_tiempoTranscurrido() {
    if (!_midiendo) return 0;
    return millis() - _tiempoInicio;
}

bool j35c1_medicionCompleta() {
    if (!_midiendo) return false;
    return (millis() - _tiempoInicio) >= VENTANA_INFILTRACION_MS;
}

void j35c1_detener() {
    _midiendo = false;
}
