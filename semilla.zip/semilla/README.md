# SEMILLA — Firmware ESP32

Sistema de medición de humedad e infiltración del suelo para trabajo de campo y laboratorio.

---

## Diagrama FSM

```
S_MENU_MODE
  ├─[Enter + "Campo"]        → S_MENU_FIELD
  ├─[Enter + "Laboratorio"]  → S_LAB_HUMIDITY
  └─[Salir]                  → (sin efecto, estado raíz)

S_MENU_FIELD
  ├─[Enter + "Humedad"]      → S_FIELD_HUMIDITY_INIT
  ├─[Enter + "Infiltración"] → S_FIELD_INFILTRATION_CHECK
  └─[Salir]                  → S_MENU_MODE

S_FIELD_HUMIDITY_INIT        → S_FIELD_HUMIDITY_MOVING (automático)

S_FIELD_HUMIDITY_MOVING
  ├─[movimiento se detiene]  → S_FIELD_HUMIDITY_SAMPLING
  └─[Salir]                  → S_FIELD_HUMIDITY_RESULT (anticipado)

S_FIELD_HUMIDITY_SAMPLING
  ├─[muestra tomada, mov. detectado, quedan slots] → S_FIELD_HUMIDITY_MOVING
  ├─[Enter]                  → S_FIELD_HUMIDITY_RESULT
  └─[Salir]                  → S_FIELD_HUMIDITY_RESULT

S_FIELD_HUMIDITY_RESULT
  └─[Enter o Salir]          → S_MENU_FIELD

S_FIELD_INFILTRATION_CHECK
  ├─[humedadPromedio > 0]    → S_FIELD_INFILTRATION_MEASURE
  └─[humedadPromedio == 0]   → S_MENU_FIELD (con advertencia)

S_FIELD_INFILTRATION_MEASURE
  ├─[ventana completada]     → S_FIELD_INFILTRATION_RESULT
  └─[Salir]                  → S_FIELD_INFILTRATION_RESULT

S_FIELD_INFILTRATION_RESULT
  └─[Enter o Salir]          → S_MENU_FIELD

S_LAB_HUMIDITY               → S_LAB_INFILTRATION (automático)
S_LAB_INFILTRATION           → S_LAB_RESULT (automático al completar ventana)

S_LAB_RESULT
  └─[Enter o Salir]          → S_MENU_MODE
```

---

## Pinout

| Componente         | Modelo    | Pin / Interfaz          |
|--------------------|-----------|-------------------------|
| Sensor humedad     | YL-69     | GPIO35 (ADC1_CH7)       |
| Sensor lluvia      | J35C1     | GPIO34 (ADC1_CH6)       |
| I2C SDA            | Compartido| GPIO21                  |
| I2C SCL            | Compartido| GPIO22                  |
| Pantalla OLED      | SSD1306   | I2C 0x3C                |
| Giroscopio/Accel   | MPU6050   | I2C 0x68                |
| Expansor pines     | MCP23017  | I2C 0x20                |
| Botón Arriba       | —         | MCP23017 GPA0           |
| Botón Abajo        | —         | MCP23017 GPA1           |
| Botón Enter        | —         | MCP23017 GPA2           |
| Botón Salir        | —         | MCP23017 GPA3           |
| LED indicador      | Rojo      | GPIO2                   |

**Nota:** GPIO34 y GPIO35 son input-only. No tienen pull-up interno en el ESP32. Los módulos de sensor deben proveer su propia referencia o instalar resistencias pull-down externas.

---

## Bibliotecas requeridas

Instalar desde el Gestor de Bibliotecas del IDE de Arduino:

| Biblioteca               | Autor    | Versión mínima |
|--------------------------|----------|----------------|
| Adafruit SSD1306         | Adafruit | 2.5+           |
| Adafruit GFX Library     | Adafruit | 1.11+          |
| Adafruit MCP23X17        | Adafruit | 2.0+           |
| Adafruit MPU6050         | Adafruit | 2.2+           |
| Adafruit Unified Sensor  | Adafruit | 1.1+           |

---

## Instrucciones de compilación

1. Instalar el soporte de ESP32 en Arduino IDE:
   - URL del gestor de tarjetas: `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`
   - Seleccionar: **ESP32 Dev Module**

2. Configuración recomendada:
   - **CPU Frequency:** 240MHz
   - **Flash Mode:** QIO
   - **Partition Scheme:** Default (o "Huge APP" si se excede el espacio)

3. Abrir `semilla/semilla.ino` → Compilar → Subir.

---

## Pendientes antes de producción

### ⚠️ FÓRMULA DE INFILTRACIÓN — REQUIERE CONFIRMACIÓN

La función `calcularInfiltracion()` en `semilla.ino` usa actualmente:

```
lámina (mm) = (gotas × VOLUMEN_GOTA_ML / AREA_CILINDRO_CM2) × 10
velocidad (mm/h) = lámina / tiempo_horas
```

Las constantes `VOLUMEN_GOTA_ML` y `AREA_CILINDRO_CM2` en `config.h` son estimaciones.
**Confirmar con el equipo:**
1. ¿Cuál es el volumen exacto (o peso) de una gota del sensor J35C1 en condiciones de campo?
2. ¿Qué diámetro de cilindro Porchet se usa?
3. ¿Las unidades de salida deben ser mm/h, cm/h, o cm/min?
4. ¿Se aplica alguna corrección por temperatura o tipo de suelo?

### Calibración YL-69

Los valores `YL69_SECO_ADC` (4095) y `YL69_MOJADO_ADC` (1200) en `config.h` deben ajustarse según la respuesta real del sensor en el tipo de suelo donde se usará el dispositivo.

---

## Estructura de archivos

```
semilla/
├── semilla.ino              # Setup, loop, FSM dispatcher y handlers
├── config.h                 # Pines, direcciones I2C, constantes, umbrales
├── fsm.h / fsm.cpp          # Enum de estados, struct DatosSemilla, transición
├── display.h / display.cpp  # Renderizado OLED por estado
├── sensors.h / sensors.cpp  # Drivers YL-69 y J35C1
├── buttons.h / buttons.cpp  # Lectura de botones vía MCP23017
├── motion.h / motion.cpp    # Detección de movimiento/reposo con MPU6050
└── README.md                # Este archivo
```
