#include "display.h"
#include "config.h"
#include <Adafruit_SSD1306.h>
#include <Adafruit_GFX.h>
#include <Arduino.h>

static Adafruit_SSD1306 oled(OLED_ANCHO, OLED_ALTO, &Wire, OLED_RESET);
static bool oledDisponible        = false;
static unsigned long ultimoRender = 0;

// ── Helpers internos ──────────────────────────────────────────────────────────

static void limpiar() {
    oled.clearDisplay();
    oled.setTextColor(SSD1306_WHITE);
}

static void cabecera(const char* titulo) {
    oled.setTextSize(1);
    oled.setCursor(0, 0);
    oled.print(titulo);
    // Línea separadora
    oled.drawLine(0, 9, OLED_ANCHO - 1, 9, SSD1306_WHITE);
}

static void cursor(int fila, const char* etiqueta, bool seleccionado) {
    oled.setTextSize(1);
    oled.setCursor(4, 13 + fila * 12);
    if (seleccionado) {
        oled.print("> ");
    } else {
        oled.print("  ");
    }
    oled.print(etiqueta);
}

static void lineaDato(int y, const char* etiqueta, float valor, int decimales = 1) {
    oled.setTextSize(1);
    oled.setCursor(0, y);
    oled.print(etiqueta);
    oled.print(valor, decimales);
}

static void lineaTexto(int y, const char* texto) {
    oled.setTextSize(1);
    oled.setCursor(0, y);
    oled.print(texto);
}

static void hint(const char* texto) {
    // Pista de navegación al fondo de la pantalla
    oled.setCursor(0, OLED_ALTO - 8);
    oled.setTextSize(1);
    oled.print(texto);
}

// ── Renders por estado ────────────────────────────────────────────────────────

static void render_menu_mode(const DatosSemilla* d) {
    cabecera("  SEMILLA v1.0");
    cursor(0, "Modo Campo",       d->menuModeSeleccion == 0);
    cursor(1, "Modo Laboratorio", d->menuModeSeleccion == 1);
    hint("^v Navegar  [E] Sel.");
}

static void render_menu_field(const DatosSemilla* d) {
    cabecera("Modo Campo");
    cursor(0, "Medir Humedad",      d->menuFieldSeleccion == 0);
    cursor(1, "Medir Infiltracion", d->menuFieldSeleccion == 1);
    hint("^v Nav  [E] Sel  [S] Atras");
}

static void render_field_humidity_init(const DatosSemilla*) {
    cabecera("Humedad - Campo");
    lineaTexto(14, "Inicializando");
    lineaTexto(24, "sensores...");
    lineaTexto(42, "Por favor espere.");
}

static void render_field_humidity_moving(const DatosSemilla* d) {
    cabecera("Humedad - Campo");
    lineaTexto(14, "Muevase al");
    lineaTexto(24, "siguiente punto.");
    oled.setTextSize(1);
    oled.setCursor(0, 37);
    oled.print("Muestras: ");
    oled.print(d->conteoMuestras);
    oled.print("/");
    oled.print(MAX_MUESTRAS_HUMEDAD);
    hint("[S] Finalizar ya");
}

static void render_field_humidity_sampling(const DatosSemilla* d) {
    cabecera("Humedad - Muestra");
    oled.setTextSize(1);
    oled.setCursor(0, 14);
    oled.print("Punto ");
    oled.print(d->conteoMuestras);
    oled.print(": ");
    if (d->conteoMuestras > 0) {
        oled.print(d->muestrasHumedad[d->conteoMuestras - 1], 1);
        oled.print("%");
    }
    oled.setCursor(0, 28);
    oled.print("LED apagado = quieto");
    hint("[E] Fin  o muevase");
}

static void render_field_humidity_result(const DatosSemilla* d) {
    cabecera("Resultado Humedad");
    oled.setTextSize(2);
    oled.setCursor(0, 14);
    oled.print(d->humedadPromedio, 1);
    oled.print("%");
    oled.setTextSize(1);
    oled.setCursor(0, 38);
    oled.print("Muestras: ");
    oled.print(d->conteoMuestras);
    hint("[E/S] Volver");
}

static void render_field_infiltration_check(const DatosSemilla* d) {
    cabecera("Infiltracion");
    if (d->mostrarAdvertencia) {
        lineaTexto(14, "ADVERTENCIA:");
        lineaTexto(24, "Mida humedad");
        lineaTexto(34, "primero.");
    } else {
        lineaTexto(14, "Verificando...");
    }
    hint("[S] Volver");
}

static void render_field_infiltration_measure(const DatosSemilla* d) {
    cabecera("Infiltracion");
    oled.setTextSize(1);
    oled.setCursor(0, 14);
    oled.print("Gotas: ");
    oled.print(d->conteoGotas);
    oled.setCursor(0, 26);
    unsigned long seg = d->tiempoInfiltracion_ms / 1000;
    oled.print("Tiempo: ");
    oled.print(seg);
    oled.print("s / ");
    oled.print(VENTANA_INFILTRACION_MS / 1000);
    oled.print("s");
    // Barra de progreso
    int progreso = map(seg, 0, VENTANA_INFILTRACION_MS / 1000, 0, OLED_ANCHO - 2);
    oled.drawRect(0, 40, OLED_ANCHO, 8, SSD1306_WHITE);
    oled.fillRect(1, 41, progreso, 6, SSD1306_WHITE);
    hint("[S] Terminar ya");
}

static void render_field_infiltration_result(const DatosSemilla* d) {
    cabecera("Result. Infiltracion");
    oled.setTextSize(1);
    oled.setCursor(0, 14);
    oled.print("Gotas: ");
    oled.print(d->conteoGotas);
    oled.setCursor(0, 26);
    oled.print("Infiltracion:");
    oled.setCursor(0, 37);
    oled.print(d->velocidadInfiltracion, 2);
    oled.print(" (ver README)");  // Unidades pendientes de confirmar
    hint("[E/S] Volver");
}

static void render_lab_humidity(const DatosSemilla*) {
    cabecera("Lab - Humedad");
    lineaTexto(14, "Midiendo humedad");
    lineaTexto(24, "del suelo...");
    lineaTexto(38, "Por favor espere.");
}

static void render_lab_infiltration(const DatosSemilla* d) {
    cabecera("Lab - Infiltracion");
    oled.setTextSize(1);
    oled.setCursor(0, 14);
    oled.print("Humedad: ");
    oled.print(d->humedadLab, 1);
    oled.print("%");
    oled.setCursor(0, 26);
    oled.print("Midiendo gotas...");
    oled.setCursor(0, 38);
    oled.print("Gotas: ");
    oled.print(d->conteoGotas);
}

static void render_lab_result(const DatosSemilla* d) {
    cabecera("Resultado Lab");
    oled.setTextSize(1);
    oled.setCursor(0, 14);
    oled.print("Humedad: ");
    oled.print(d->humedadLab, 1);
    oled.print("%");
    oled.setCursor(0, 26);
    oled.print("Gotas: ");
    oled.print(d->conteoGotas);
    oled.setCursor(0, 38);
    oled.print("Infiltracion:");
    oled.setCursor(0, 49);
    oled.print(d->velocidadInfiltracion, 2);
    hint("[E/S] Menu principal");
}

// ── API pública ───────────────────────────────────────────────────────────────

bool display_init() {
    if (!oled.begin(SSD1306_SWITCHCAPVCC, I2C_ADDR_OLED)) {
        oledDisponible = false;
        return false;
    }
    oledDisponible = true;
    oled.clearDisplay();
    oled.setTextColor(SSD1306_WHITE);
    oled.setTextSize(1);

    // Pantalla de bienvenida
    oled.setCursor(28, 10);
    oled.setTextSize(2);
    oled.print("SEMILLA");
    oled.setTextSize(1);
    oled.setCursor(20, 38);
    oled.print("Iniciando...");
    oled.display();
    return true;
}

void display_update(EstadoFSM estado, const DatosSemilla* d, bool forzar) {
    if (!oledDisponible) return;

    unsigned long ahora = millis();
    if (!forzar && (ahora - ultimoRender < INTERVALO_DISPLAY_MS)) return;
    ultimoRender = ahora;

    limpiar();

    switch (estado) {
        case S_MENU_MODE:                  render_menu_mode(d);                break;
        case S_MENU_FIELD:                 render_menu_field(d);               break;
        case S_FIELD_HUMIDITY_INIT:        render_field_humidity_init(d);      break;
        case S_FIELD_HUMIDITY_MOVING:      render_field_humidity_moving(d);    break;
        case S_FIELD_HUMIDITY_SAMPLING:    render_field_humidity_sampling(d);  break;
        case S_FIELD_HUMIDITY_RESULT:      render_field_humidity_result(d);    break;
        case S_FIELD_INFILTRATION_CHECK:   render_field_infiltration_check(d); break;
        case S_FIELD_INFILTRATION_MEASURE: render_field_infiltration_measure(d); break;
        case S_FIELD_INFILTRATION_RESULT:  render_field_infiltration_result(d);  break;
        case S_LAB_HUMIDITY:               render_lab_humidity(d);             break;
        case S_LAB_INFILTRATION:           render_lab_infiltration(d);         break;
        case S_LAB_RESULT:                 render_lab_result(d);               break;
    }

    oled.display();
}
