#pragma once

// Posición del MPU6050 expresada como vector de aceleración (m/s²)
struct PosicionMPU {
    float ax, ay, az;
};

// Inicializa el MPU6050 y toma una lectura base para comparación
void       motion_init();

// Debe llamarse en cada iteración del loop; actualiza el estado interno
void       motion_actualizar();

// True si el módulo se detecta en movimiento respecto a la base
bool       motion_hayMovimiento();

// True si el módulo ha estado quieto durante TIEMPO_REPOSO_MS ms
bool       motion_estaEnReposo();

// Magnitud del vector de aceleración actual (m/s²)
float      motion_obtenerAceleracionTotal();

// Vector de aceleración actual (útil para registrar posición de cada muestra)
PosicionMPU motion_obtenerPosicion();

// Actualiza la lectura base al estado actual (útil al inicio de cada nueva muestra)
void       motion_resetearBase();

// True si el MPU6050 respondió correctamente en el bus I2C
bool       motion_disponible();
