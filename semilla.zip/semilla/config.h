#pragma once

// ── Pines analógicos (sensores) ──────────────────────────────────────────────
#define PIN_SENSOR_HUMEDAD    35   // YL-69  → GPIO35 (ADC1_CH7, input-only, sin pull-up interno)
#define PIN_SENSOR_LLUVIA     34   // J35C1  → GPIO34 (ADC1_CH6, input-only, sin pull-up interno)

// ── Bus I2C compartido ────────────────────────────────────────────────────────
#define PIN_I2C_SDA           21
#define PIN_I2C_SCL           22

// ── Direcciones I2C ───────────────────────────────────────────────────────────
#define I2C_ADDR_OLED         0x3C
#define I2C_ADDR_MPU6050      0x68
#define I2C_ADDR_MCP23017     0x20

// ── Botones vía MCP23017 (puerto GPA) ─────────────────────────────────────────
#define MCP_BTN_UP            0    // GPA0
#define MCP_BTN_DOWN          1    // GPA1
#define MCP_BTN_ENTER         2    // GPA2
#define MCP_BTN_EXIT          3    // GPA3

// ── LED indicador ─────────────────────────────────────────────────────────────
#define PIN_LED_ROJO          2    // GPIO2 (LED integrado en la mayoría de ESP32)

// ── Parámetros de muestreo de humedad ─────────────────────────────────────────
#define MAX_MUESTRAS_HUMEDAD  20   // Máximo de muestras por sesión de campo

// ── Parámetros de botones ─────────────────────────────────────────────────────
#define DEBOUNCE_MS           50   // Tiempo mínimo entre detecciones de botón (ms)

// ── Parámetros de detección de movimiento ─────────────────────────────────────
#define UMBRAL_MOVIMIENTO     0.5f    // Diferencia en aceleración (m/s²) para detectar movimiento
#define TIEMPO_REPOSO_MS      1500UL  // Tiempo sin movimiento para considerar posición estable (ms)

// ── Parámetros de infiltración ────────────────────────────────────────────────
#define VENTANA_INFILTRACION_MS   60000UL  // Duración de la ventana de medición (60 s)
// TODO: Confirmar fórmula exacta de infiltración antes de ajustar estas constantes
#define AREA_CILINDRO_CM2         78.54f   // π × r² con r=5 cm (cilindro estándar Porchet)
#define VOLUMEN_GOTA_ML           0.05f    // Volumen estimado por gota del J35C1 — PENDIENTE CONFIRMAR

// ── Calibración YL-69 ─────────────────────────────────────────────────────────
// Ajustar según la respuesta real del sensor en campo
#define YL69_SECO_ADC         4095   // Lectura ADC en suelo completamente seco   (→ 0 %)
#define YL69_MOJADO_ADC       1200   // Lectura ADC en suelo saturado de agua      (→ 100 %)

// ── Parámetros de detección de gota J35C1 ────────────────────────────────────
#define UMBRAL_GOTA_ADC       2000   // Valor ADC por debajo del cual se considera "gota presente"

// ── Pantalla OLED ─────────────────────────────────────────────────────────────
#define OLED_ANCHO            128
#define OLED_ALTO             64
#define OLED_RESET            -1     // Reset controlado por software; -1 = sin pin dedicado

// ── Intervalo de refresco de pantalla ─────────────────────────────────────────
#define INTERVALO_DISPLAY_MS  150UL  // Refresco máximo cada 150 ms para no saturar I2C
