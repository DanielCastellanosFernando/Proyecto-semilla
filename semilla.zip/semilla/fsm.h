#pragma once
#include "config.h"

// ── Todos los estados posibles de la máquina de estados ──────────────────────
enum EstadoFSM {
    S_MENU_MODE = 0,
    S_MENU_FIELD,
    S_FIELD_HUMIDITY_INIT,
    S_FIELD_HUMIDITY_MOVING,
    S_FIELD_HUMIDITY_SAMPLING,
    S_FIELD_HUMIDITY_RESULT,
    S_FIELD_INFILTRATION_CHECK,
    S_FIELD_INFILTRATION_MEASURE,
    S_FIELD_INFILTRATION_RESULT,
    S_LAB_HUMIDITY,
    S_LAB_INFILTRATION,
    S_LAB_RESULT
};

// ── Datos compartidos entre todos los estados ─────────────────────────────────
struct DatosSemilla {
    // Humedad (campo)
    float muestrasHumedad[MAX_MUESTRAS_HUMEDAD];
    int   conteoMuestras;
    float humedadPromedio;     // 0.0 significa "aún no calculado"

    // Posiciones MPU por muestra (para verificar que son puntos distintos)
    float posAx[MAX_MUESTRAS_HUMEDAD];
    float posAy[MAX_MUESTRAS_HUMEDAD];
    float posAz[MAX_MUESTRAS_HUMEDAD];

    // Infiltración
    int            conteoGotas;
    unsigned long  tiempoInfiltracion_ms;
    float          velocidadInfiltracion;  // Unidades: PENDIENTE (ver TODO en config.h)

    // Navegación de menús
    int menuModeSeleccion;   // 0 = Campo, 1 = Laboratorio
    int menuFieldSeleccion;  // 0 = Humedad, 1 = Infiltración

    // Humedad de laboratorio (lectura única)
    float humedadLab;

    // Advertencia de flujo (p.ej. infiltración sin humedad previa)
    bool mostrarAdvertencia;
};

// ── Variables globales de la FSM ─────────────────────────────────────────────
extern EstadoFSM  estadoActual;
extern DatosSemilla datos;
extern bool       estadoEntrada;  // true durante el primer tick de un estado nuevo

// ── API de la FSM ─────────────────────────────────────────────────────────────
void fsm_init();
void fsm_transicion(EstadoFSM nuevoEstado);
