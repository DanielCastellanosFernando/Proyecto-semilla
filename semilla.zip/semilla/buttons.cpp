#include "buttons.h"
#include "config.h"
#include <Adafruit_MCP23X17.h>
#include <Arduino.h>

static Adafruit_MCP23X17 mcp;
static bool   mcpDisponible    = false;
static unsigned long ultimoDebounce = 0;
static Boton  ultimoBoton      = BTN_NONE;

void buttons_init() {
    if (!mcp.begin_I2C(I2C_ADDR_MCP23017)) {
        // Si el expansor no responde en el bus I2C, se deshabilita silenciosamente.
        // El firmware continúa; buttons_leer() devolverá BTN_NONE siempre.
        mcpDisponible = false;
        return;
    }
    // Configurar GPA0-GPA3 como entradas con pull-up interno del MCP23017
    for (int pin = 4; pin <= 7; pin++) {
        mcp.pinMode(pin, INPUT_PULLUP);
    }
    mcpDisponible = true;
}

Boton buttons_leer() {
    if (!mcpDisponible) return BTN_NONE;

    unsigned long ahora = millis();
    if (ahora - ultimoDebounce < DEBOUNCE_MS) return BTN_NONE;

    // Botones activos en LOW (pull-up activo → pin = HIGH cuando no pulsado)
    bool presionado[4] = {
        !mcp.digitalRead(MCP_BTN_UP),
        !mcp.digitalRead(MCP_BTN_DOWN),
        !mcp.digitalRead(MCP_BTN_ENTER),
        !mcp.digitalRead(MCP_BTN_EXIT)
    };

    Boton botonActual = BTN_NONE;
    if      (presionado[0]) botonActual = BTN_UP;
    else if (presionado[1]) botonActual = BTN_DOWN;
    else if (presionado[2]) botonActual = BTN_ENTER;
    else if (presionado[3]) botonActual = BTN_EXIT;

    // Disparar solo en el flanco de bajada (nuevo botón distinto al anterior)
    if (botonActual != BTN_NONE && botonActual != ultimoBoton) {
        ultimoDebounce = ahora;
        ultimoBoton    = botonActual;
        return botonActual;
    }

    // Resetear el "último botón" al soltar para permitir próxima pulsación
    if (botonActual == BTN_NONE) {
        ultimoBoton = BTN_NONE;
    }

    return BTN_NONE;
}
