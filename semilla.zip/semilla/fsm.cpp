#include "fsm.h"
#include <string.h>

EstadoFSM   estadoActual  = S_MENU_MODE;
DatosSemilla datos        = {};
bool        estadoEntrada = true;  // Al arrancar, S_MENU_MODE es un estado "nuevo"

void fsm_init() {
    estadoActual  = S_MENU_MODE;
    estadoEntrada = true;
    memset(&datos, 0, sizeof(datos));
}

// Realiza la transición y activa el flag de entrada para que el nuevo
// estado ejecute su inicialización en el primer tick del loop.
void fsm_transicion(EstadoFSM nuevoEstado) {
    estadoActual  = nuevoEstado;
    estadoEntrada = true;
}
