#pragma once

// Enum de botones expuesto al resto del firmware
enum Boton {
    BTN_NONE  = 0,
    BTN_UP,
    BTN_DOWN,
    BTN_ENTER,
    BTN_EXIT
};

// Inicializa el MCP23017 y configura GPA0-GPA3 como INPUT_PULLUP
void  buttons_init();

// Retorna el botón presionado en este ciclo (con debounce incorporado).
// Solo dispara UNA vez por pulsación física; regresa BTN_NONE si no hay novedad.
Boton buttons_leer();
