#pragma once

// ═══════════════════════════════════════════════════════════════
//  YL-69 — Sensor capacitivo de humedad del suelo
// ═══════════════════════════════════════════════════════════════

// Inicializa el canal ADC (GPIO35 es input-only; no requiere pinMode especial en ESP32)
void  yl69_init();

// Retorna humedad como porcentaje [0.0 – 100.0]
// El mapeo se basa en YL69_SECO_ADC y YL69_MOJADO_ADC definidos en config.h
float yl69_leer();

// True si el sensor fue inicializado sin errores
bool  yl69_listo();

// ═══════════════════════════════════════════════════════════════
//  J35C1 — Sensor de detección de lluvia / gotas
// ═══════════════════════════════════════════════════════════════

// Inicializa el canal ADC (GPIO34 es input-only)
void j35c1_init();

// Inicia una nueva ventana de medición (resetea conteo y tiempo)
void j35c1_iniciarMedicion();

// Debe llamarse en cada iteración del loop cuando se está midiendo.
// Detecta flancos descendentes en el ADC para contar gotas individuales.
void j35c1_actualizar();

// Retorna el conteo de gotas acumulado desde iniciarMedicion()
int  j35c1_conteoGotas();

// Retorna milisegundos transcurridos desde iniciarMedicion()
unsigned long j35c1_tiempoTranscurrido();

// True cuando se cumplió VENTANA_INFILTRACION_MS
bool j35c1_medicionCompleta();

// Detiene la medición activa
void j35c1_detener();
