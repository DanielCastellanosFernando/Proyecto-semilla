#pragma once
#include "fsm.h"

// Inicializa la pantalla OLED SSD1306 vía I2C
// Wire.begin() debe haberse llamado antes de esta función
bool display_init();

// Renderiza el contenido correspondiente al estado actual de la FSM.
// Incluye lógica de throttle: solo envía datos al display cada INTERVALO_DISPLAY_MS ms,
// excepto cuando forzar=true (p.ej. al entrar a un estado nuevo).
void display_update(EstadoFSM estado, const DatosSemilla* d, bool forzar = false);
