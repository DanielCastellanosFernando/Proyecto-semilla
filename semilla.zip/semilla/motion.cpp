#include "motion.h"
#include "config.h"
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Arduino.h>
#include <math.h>

static Adafruit_MPU6050 mpu;
static bool mpuDisponible = false;

// Lectura base (tomada en motion_init o motion_resetearBase)
static float axBase = 0.0f, ayBase = 0.0f, azBase = 0.0f;

// Lectura actual
static float axActual = 0.0f, ayActual = 0.0f, azActual = 0.0f;

// Estado de reposo
static bool          enReposo           = true;
static unsigned long tiempoSinMovimiento = 0;

void motion_init() {
    if (!mpu.begin(I2C_ADDR_MPU6050)) {
        mpuDisponible = false;
        return;
    }
    mpuDisponible = true;

    mpu.setAccelerometerRange(MPU6050_RANGE_2_G);
    mpu.setGyroRange(MPU6050_RANGE_250_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

    // Capturar lectura base inicial
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    axBase = a.acceleration.x;
    ayBase = a.acceleration.y;
    azBase = a.acceleration.z;
    axActual = axBase;
    ayActual = ayBase;
    azActual = azBase;

    enReposo            = true;
    tiempoSinMovimiento = millis();
}

void motion_actualizar() {
    if (!mpuDisponible) return;

    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    axActual = a.acceleration.x;
    ayActual = a.acceleration.y;
    azActual = a.acceleration.z;

    float dx = fabsf(axActual - axBase);
    float dy = fabsf(ayActual - ayBase);
    float dz = fabsf(azActual - azBase);
    float delta = sqrtf(dx * dx + dy * dy + dz * dz);

    if (delta > UMBRAL_MOVIMIENTO) {
        enReposo            = false;
        tiempoSinMovimiento = millis();
    } else {
        if ((millis() - tiempoSinMovimiento) >= TIEMPO_REPOSO_MS) {
            enReposo = true;
        }
    }
}

bool motion_hayMovimiento() {
    return !enReposo;
}

bool motion_estaEnReposo() {
    return enReposo;
}

float motion_obtenerAceleracionTotal() {
    return sqrtf(axActual * axActual + ayActual * ayActual + azActual * azActual);
}

PosicionMPU motion_obtenerPosicion() {
    return { axActual, ayActual, azActual };
}

// Actualiza la base al vector actual para que los movimientos futuros
// se midan relativo a la nueva posición (útil entre muestras de campo)
void motion_resetearBase() {
    axBase = axActual;
    ayBase = ayActual;
    azBase = azActual;
    enReposo            = true;
    tiempoSinMovimiento = millis();
}

bool motion_disponible() {
    return mpuDisponible;
}
